"""
The codes and patterns in this package are built on CheXpert labeler.
https://github.com/stanfordmlgroup/chexpert-labeler
"""
