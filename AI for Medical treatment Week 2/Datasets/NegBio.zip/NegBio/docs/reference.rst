Reference
=========

*  Peng Y, Wang X, Lu L, Bagheri M, Summers RM, Lu Z. `NegBio: a high-performance tool for negation and uncertainty
   detection in radiology reports <https://arxiv.org/abs/1712.05898>`_. *AMIA 2018 Informatics Summit*. 2018.
*  Wang X, Peng Y, Lu L, Bagheri M, Lu Z, Summers R. `ChestX-ray8: Hospital-scale Chest X-ray database and benchmarks
   on weakly-supervised classification and localization of common thorax diseases <https://arxiv.org/abs/1705.02315>`_.
   *IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*. 2017, 2097-2106.